# GPUd Helm Chart

This Helm chart deploys [GPUd](https://github.com/leptonai/gpud) as a [DaemonSet](https://kubernetes.io/docs/concepts/workloads/controllers/daemonset/) on a Kubernetes cluster.

GPUd is a lightweight, high-performance daemon that monitors GPU resources. This chart is the recommended way to deploy GPUd on Kubernetes.

The default [`nvcr.io/nvidia/lepton/gpud` image](https://catalog.ngc.nvidia.com/orgs/nvidia/lepton/containers/gpud/-/tags)
is public. No image pull secret or NGC API key is required.
Packaged charts derive the image tag from the pushed Git tag through
`appVersion`; `values.yaml` does not pin a release tag.

## Prerequisites

- Kubernetes 1.19+
- [Helm](https://helm.sh/) 3.16.1+

## Installing the Chart

The chart is published through both
[GitHub Pages](https://leptonai.github.io/gpud) and the
[NGC catalog](https://catalog.ngc.nvidia.com/orgs/nvidia/lepton/helm-charts/gpud/-).

To install from GitHub Pages, add the repository and resolve the latest
published version from `unstable_latest.txt`:

```bash
helm repo add gpud https://leptonai.github.io/gpud
helm repo update gpud

GPUD_VERSION="$(curl -fsSL https://pkg.gpud.dev/unstable_latest.txt)"
GPUD_VERSION="${GPUD_VERSION#v}"

helm upgrade --install my-gpud gpud/gpud \
  --version "$GPUD_VERSION" \
  --set image.repository=nvcr.io/nvidia/lepton/gpud \
  --create-namespace \
  --namespace gpud
```

Or pull the same chart from NGC:

```bash
helm pull https://helm.ngc.nvidia.com/nvidia/lepton/charts/gpud-0.12.24.tgz
```

### Migrating from the OCI chart registry

GitHub Container Registry no longer hosts GPUd charts. Replace an OCI install
such as `oci://ghcr.io/leptonai/gpud` with the `gpud/gpud` chart after adding
the repository above:

```bash
helm upgrade --install my-gpud gpud/gpud \
  --version "$GPUD_VERSION" \
  --set image.repository=nvcr.io/nvidia/lepton/gpud \
  --create-namespace \
  --namespace gpud
```

The container image remains independently configurable through
`image.repository` and `image.tag`.

To let Helm select the newest chart version automatically:

```bash
helm upgrade --install my-gpud gpud/gpud \
  --set image.repository=nvcr.io/nvidia/lepton/gpud \
  --create-namespace \
  --namespace gpud
```

### Installing with Custom Values

To install with a specific image tag and disable telemetry:

```bash
helm install my-gpud gpud/gpud \
  --create-namespace \
  --namespace gpud \
  --set image.repository=nvcr.io/nvidia/lepton/gpud \
  --set image.tag="<MY_IMAGE_TAG>" \
  --set gpud.telemetry.enabled=false
```

You can also provide a custom `values.yaml` file:

```bash
helm install my-gpud gpud/gpud \
  --namespace gpud -f my-values.yaml
```

### Upgrading installations without a startup probe

GPUd completes login and machine-info collection before serving `/healthz`.
Slow or unreachable metadata endpoints can delay startup beyond the liveness
probe's approximately 30-second budget. The chart's startup probe allows
approximately five minutes before Kubernetes restarts the container, while
keeping liveness checks disabled until startup succeeds.

When upgrading an older installation, use the new chart defaults with your
existing overrides (Helm 3.16.1+):

```bash
helm upgrade my-gpud gpud/gpud \
  --namespace gpud \
  --version "$GPUD_VERSION" \
  --reset-then-reuse-values
```

Plain `--reuse-values` retains the old chart defaults and can omit the new
startup probe. The chart rejects liveness without startup protection. If your
saved overrides explicitly disable the startup probe, replace that override
with the `startupProbe` mapping from the new chart's `values.yaml`. Preserve
any custom listener port in both probes. To intentionally disable probes,
set both `startupProbe: null` and `livenessProbe: null`.

Before applying, add `--dry-run` and check the rendered GPUd container has
`startupProbe` with the intended handler and timeout budget. After applying,
check that the pods become Ready and their restart counts remain stable
through repeated checks; a successful Helm upgrade alone does not prove
slow-login recovery.

### Reboot Support Inside DaemonSet Pods

The chart passes `gpud.rebootCommands` to `gpud run --reboot-commands`. By
default, it uses `nsenter` to enter the host namespaces through PID 1 and ask
the host init system to reboot the node. This is the path needed when GPUd runs
inside a privileged DaemonSet pod rather than directly as a host systemd
service.

The default reboot path depends on these chart defaults:

- `hostPID: true`
- `securityContext.privileged: true`
- `securityContext.runAsUser: 0`
- `securityContext.allowPrivilegeEscalation: true`

Use a values file for multi-line reboot commands:

```yaml
gpud:
  rebootCommands: |
    set -o errexit
    set -o nounset

    if command -v nsenter >/dev/null 2>&1; then
      if nsenter --target 1 --mount --uts --ipc --net --pid --cgroup --root --wd=/ -- /usr/bin/systemctl reboot; then
        exit 0
      fi
      nsenter --target 1 --mount --uts --ipc --net --pid --cgroup --root --wd=/ -- /sbin/reboot
      exit 0
    fi

    sudo reboot
```

Set `gpud.rebootCommands: ""` to keep GPUd's built-in reboot behavior instead.
If `gpud.commandOverride` is set, the default startup wrapper is bypassed, so
include `--reboot-commands` in the override when node reboot support is needed.

### Disk Inspection Inside DaemonSet Pods

The disk component shells out to `findmnt` and `lsblk` and measures filesystem
usage via `statfs`. Run from inside a container, these report the container's
overlay rootfs instead of the node's real disks (the root disk and any data
disks). The chart therefore wraps each of them with `nsenter --target 1 --mount`
by default so they run in the host's mount namespace:

```yaml
gpud:
  findmntCommands: "nsenter --target 1 --mount -- findmnt"
  lsblkCommands: "nsenter --target 1 --mount -- lsblk"
  blockdevUsageCommands: "nsenter --target 1 --mount -- df"
```

These map to `gpud run --findmnt-commands`, `--lsblk-commands`, and
`--blockdev-usage-commands`. The value is the invocation prefix; GPUd appends the
flags it controls (for example `findmnt --target ... --json --df`, or
`df -T -B1 -P`). They depend on the same chart defaults as `rebootCommands`
(`hostPID: true`, `securityContext.privileged: true`, `runAsUser: 0`).

Set any of these to `""` to keep GPUd's built-in in-namespace behavior, which is
appropriate when GPUd runs directly on the host (e.g. as a systemd service) or in
a non-privileged pod. As with reboot, if `gpud.commandOverride` is set the
default startup wrapper is bypassed, so include these flags in the override when
host disk inspection is needed.

### Containerd Monitoring Inside DaemonSet Pods

When the NVIDIA configuration check fails, GPUd adds live containerd details
from a bounded verbose CRI status request: CDI support, the default handler,
and configured handlers. If a READY local sandbox references a missing handler,
the reason also names that pod and handler. These are supplemental diagnostics;
they never change the existing health verdict, configuration checks, or startup
grace period. Pending pods without a sandbox are not covered by these details.

The containerd component checks the host's containerd socket and CRI endpoint,
reads `/etc/containerd/config.toml` to verify the NVIDIA runtime is configured,
and checks whether the containerd systemd service is active. Run from inside a
container, the socket/config are not visible and the systemd check only sees the
container's own service manager. The chart addresses both:

```yaml
gpud:
  # Bind-mount the host's containerd dirs (default true):
  #   /run/containerd (read-write)  -> socket + CRI endpoint
  #   /etc/containerd (read-only)   -> config.toml NVIDIA-runtime check
  # Both use hostPath DirectoryOrCreate, so the pod still starts without containerd.
  mountContainerd: true

  # Bind-mount the host's CRI-O dir (default true):
  #   /run/crio (read-write)        -> crio.sock CRI endpoint, dialed to detect
  #                                    that CRI-O is the node's runtime so a
  #                                    missing containerd socket is not
  #                                    misreported as unhealthy
  mountCrio: true

  # Check whether the host's containerd service is active (exit code 0 = active),
  # mapped to "gpud run --containerd-service-active-commands".
  containerdServiceActiveCommands: "nsenter --target 1 --mount -- systemctl is-active containerd"
```

On nodes that run CRI-O instead of containerd, keep `gpud.mountCrio: true`
(the default): the component dials the CRI endpoint at `/run/crio/crio.sock`
to recognize a live CRI-O node and treats the absent containerd socket as
expected, not unhealthy. Leaving the default on nodes without CRI-O is also
safe: the mount creates an empty `/run/crio`, gpud finds no `crio.sock`, and
the containerd check behaves as before. On nodes that run neither containerd
nor CRI-O, set `gpud.mountContainerd: false` and
`gpud.containerdServiceActiveCommands: ""`.

### NVSentinel Integration

By default the chart enables GPUd's NVSentinel sink: GPUd serves the
NVSentinel PlatformConnector gRPC API on a unix socket, and the node's
NVSentinel platform-connector dials it to forward health events
(Xid/SXid/InfiniBand), which GPUd components then deduplicate against their
own detection:

```yaml
gpud:
  nvsentinel:
    enabled: true
    socketPath: /var/run/nvsentinel/gpud.sock
```

GPUd only listens — it never dials NVSentinel — so nodes without NVSentinel
are unaffected: the listener idles and components keep using their native
detection (kmsg, NVML, ...). GPUd is simply ready whenever NVSentinel comes
online. The socket's parent directory (`/var/run/nvsentinel`) is bind-mounted
from the host with `DirectoryOrCreate`, which is what lets the
platform-connector pod — it mounts the same host directory at its own
`/var/run` — reach the socket at `/var/run/gpud.sock`. On nodes without
NVSentinel this leaves only an empty host directory.

Requires a gpud image with the LEP-6075 NVSentinel sink (v0.13.0+). On older
images the unknown `--nvsentinel-endpoint` flag fails startup — set
`gpud.nvsentinel.enabled: false` when pinning an older `image.tag`. As with
the other startup flags, if `gpud.commandOverride` is set the default startup
wrapper is bypassed, so include `--nvsentinel-endpoint` in the override when
the sink is needed.

### Enabling or Disabling Components

Set `gpud.components` (a list) to control which components run; it is rendered
to `gpud run --components`. Empty (the default) enables all components.

```yaml
gpud:
  # Denylist: disable selected components, keep everything else
  # (requires a gpud image with the LEP-6439 fix):
  components: ["-docker", "-library"]

  # Allowlist: run ONLY the listed components:
  # components: ["containerd", "os", "accelerator-nvidia-error-xid"]
```

On older gpud images without the LEP-6439 fix, a denylist-only list disables
ALL components -- use an explicit allowlist there instead.

### Session Token from a Secret

When `nodeLabelExporter.enabled=true`, the chart's init container can read the
session token from a node label. To read it from an existing Kubernetes Secret
instead, set `gpud.tokenSecret`; the token is injected as the `TOKEN` env via
`secretKeyRef` and takes priority over any token label:

```yaml
gpud:
  tokenSecret:
    name: gpud-token   # existing Secret in the release namespace
    key: TOKEN
```

To have the Helm release create and own that Secret, also set `create` and
`value`:

```yaml
gpud:
  tokenSecret:
    create: true
    name: gpud-token
    key: TOKEN
    value: "<YOUR_GPUD_SESSION_TOKEN>"
```

The token is stored in Helm values and release state when `value` is used.
Restrict access to both.

### BYOK Worker Cluster Example

The public default image also works for BYOK clusters without an image pull
secret. Install or upgrade with a values file like this (a full BYOK overlay):

```yaml
gpud:
  endpoint: gpud-manager-dev02.dev02.dgxc-lepton-dev.nvidia.com
  # Create and use the gpud-token Secret as part of this Helm release.
  tokenSecret:
    create: true
    name: gpud-token
    key: TOKEN
    value: "<YOUR_GPUD_SESSION_TOKEN>"
  # The node also exposes /dev/mem on this platform.
  mountHostDevMem: true
  # reboot / disk (findmnt,lsblk,df) / containerd command overrides and the
  # containerd socket+config mounts are chart defaults (nsenter wrappers).

# Pass the per-node platform machine ID from the node label to
# "gpud run --machine-id", so GPUd rejoins as the SAME machine after a pod
# replacement, node reboot, or reimage (even if /etc/machine-id changes).
# This is intentionally init-only: gpud reads the file once at startup, so a
# sidecar update could not reconfigure the already-running process.
nodeLabelExporter:
  enabled: true
  labelKeys:
    machineId: lepton.ai/machine-id
  resources: null

# GPU workloads on these nodes request whole nodes, so the DaemonSet should
# consume none of the node's allocatable resources. null (not {}) deletes the
# chart's default requests/limits; the pod runs as BestEffort and its
# system-node-critical priority still keeps it scheduled first, evicted last.
resources: null

# Schedule only on the intended worker nodes.
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: node.lepton.ai/dedicated-node-group-id
              operator: Exists
            - key: lepton.ai/machine-id
              operator: Exists
```

Install or upgrade with that values file in the same namespace:

```bash
helm upgrade --install gpud gpud/gpud \
  --create-namespace \
  --namespace gpud \
  --set image.repository=nvcr.io/nvidia/lepton/gpud \
  -f byok-values.yaml
```

This makes a `helm install` a drop-in replacement for a hand-written GPUd
DaemonSet: the machine ID is preserved (node label + the persisted
`/var/lib/gpud` hostPath), the token comes from the Secret, and the disk and
containerd components report the node's real state via the nsenter wrappers.

## Uninstalling the Chart

To uninstall the `my-gpud` release:

```bash
helm uninstall my-gpud --namespace gpud
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

For a full list of configurable parameters, see the [values.yaml](values.yaml) file.
